#define TAM_MAX 100

void imprime_matriz(int M[][TAM_MAX], int m, int n);

int zera_3consec(int M[][TAM_MAX], int m, int n);

void translada_zeros(int M[][TAM_MAX], int m, int n);