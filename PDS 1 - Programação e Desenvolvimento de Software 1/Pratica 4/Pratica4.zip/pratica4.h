//-----Atividade 1-----
float paraMetrosPorSegundo(float v);

//-----Atividade 2-----
float areaCirculo(float raio);

//-----Atividade 3-----
int maior3(int n1, int n2, int n3);

//-----Atividade 4-----
int ehPar(int n);

//-----Atividade 5-----
int ehDivisivelPor3ou5(int N);

//-----Atividade 6 e 7-----
float pesoIdeal(float h, char sexo);

//-----Atividade 7-----
float diferencaPeso(float pa, float pi);

//-----Atividade 8-----
int somaImpares(int m);

//-----Atividade 9-----
double fatorial(int M);

//-----Atividade 10-----
int EhDivisivelPor3ou5(int j);
int somaNumerosDiv3ou5(int b);

//-----Atividade 11-----
float calculaMedia(int x, int y, int z, int operacao);

//-----Atividade 12-----
int numeroDivisores(int g);

//-----Atividade 13-----
int enesimoFibonacci(int U);

//-----Atividade 14-----
int mdc(unsigned int num1, unsigned int num2);

//-----Atividade 15-----
int mmc(unsigned int num3, unsigned int num4);

//-----Atividade 16-----
int MDC(unsigned int num5, unsigned int num6);
int MMC(unsigned int num5, unsigned int num6);